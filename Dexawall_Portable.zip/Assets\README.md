# Dexawall Icon Placeholder

This directory should contain `icon.ico` - a multi-resolution Windows icon file.

## Required Sizes
- 16x16
- 32x32
- 48x48
- 256x256

## Icon Design Suggestions
- Clean, simple wallpaper/display symbol
- Works well at small sizes (tray icon)
- Matches dark theme aesthetics

## How to Create
1. Use an icon editor like:
   - [RealFaviconGenerator](https://realfavicongenerator.net/)
   - [ICO Convert](https://icoconvert.com/)
   - IcoFX or GIMP with ICO plugin

2. Or use a placeholder by renaming any `.ico` file to `icon.ico`
