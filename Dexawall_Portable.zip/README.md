# Dexawall 🖼️

**A premium, high-performance wallpaper manager for Windows.**

Dexawall allows you to manage wallpapers across multiple monitors with ease. Just drop it in a folder and run!

## Features

- **Multi-Monitor Support**: Set different wallpapers for each screen.
- **Online Search**: Browse and download amazing photos from Unsplash.
- **Scheduler**: Automatically change wallpapers at set intervals.
- **Smart Performance**: Zero resource usage when sleeping or gaming.
- **Portable**: No installation required. Settings are saved locally.

## How to Install

1.  Download the `Dexawall.exe` file.
2.  Place it in a folder (e.g., `C:\Apps\Dexawall`).
3.  Run `Dexawall.exe`.
4.  The app will appear in your **System Tray** (near the clock).
5.  Double-click the tray icon to open Settings.

## Usage

- **Add Wallpapers**: Go to the **Library** tab and select a folder containing images.
- **Change Wallpaper**: Click any thumbnail in the grid.
- **Online**: Use the **Online** tab to search for new wallpapers (e.g., "nature", "city").
- **Scheduler**: Enable the scheduler in Settings to rotate wallpapers automatically.

## Requirements

- Windows 10 or Windows 11 (x64)
- No other dependencies (Self-contained)

---
*Created by Dexawall Team*
